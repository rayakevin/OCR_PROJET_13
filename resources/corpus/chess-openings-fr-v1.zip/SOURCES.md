# Sources du corpus français

339 passages ; 30 articles.

Textes : contributeurs et contributrices de Wikipédia en français, attribués par les liens vers les articles ci-dessous et leurs historiques.
Licence des textes adaptés : CC BY-SA 4.0, https://creativecommons.org/licenses/by-sa/4.0/
Conditions de réutilisation : https://foundation.wikimedia.org/wiki/Policy:Terms_of_Use/en#7._Licensing_of_Content

Transformations : extraction du texte HTML, nettoyage, sélection et regroupement en passages par section, ajout du titre et du chemin de section pour l'encodage. Aucune image n'est incluse. Les révisions Wikipédia exactes n'ont pas été enregistrées lors de la collecte ; les liens peuvent avoir évolué. L'archive fige les textes effectivement encodés.

Modèle : Qwen/Qwen3-Embedding-0.6B ; révision : 97b0c614be4d77ee51c0cef4e5f07c00f9eb65b3.
Date d'encodage : 2026-09-23T12:48:40.419934+00:00.
Les vecteurs sont des données calculées ; aucun poids du modèle n'est redistribué.

- [Début Réti](https://fr.wikipedia.org/wiki/D%C3%A9but_R%C3%A9ti) — [historique](https://fr.wikipedia.org/wiki/D%C3%A9but_R%C3%A9ti?action=history)
- [Défense Alekhine](https://fr.wikipedia.org/wiki/D%C3%A9fense_Alekhine) — [historique](https://fr.wikipedia.org/wiki/D%C3%A9fense_Alekhine?action=history)
- [Défense Benoni](https://fr.wikipedia.org/wiki/D%C3%A9fense_Benoni) — [historique](https://fr.wikipedia.org/wiki/D%C3%A9fense_Benoni?action=history)
- [Défense Caro-Kann](https://fr.wikipedia.org/wiki/D%C3%A9fense_Caro-Kann) — [historique](https://fr.wikipedia.org/wiki/D%C3%A9fense_Caro-Kann?action=history)
- [Défense Grünfeld](https://fr.wikipedia.org/wiki/D%C3%A9fense_Gr%C3%BCnfeld) — [historique](https://fr.wikipedia.org/wiki/D%C3%A9fense_Gr%C3%BCnfeld?action=history)
- [Défense Philidor](https://fr.wikipedia.org/wiki/D%C3%A9fense_Philidor) — [historique](https://fr.wikipedia.org/wiki/D%C3%A9fense_Philidor?action=history)
- [Défense Pirc](https://fr.wikipedia.org/wiki/D%C3%A9fense_Pirc) — [historique](https://fr.wikipedia.org/wiki/D%C3%A9fense_Pirc?action=history)
- [Défense est-indienne](https://fr.wikipedia.org/wiki/D%C3%A9fense_est-indienne) — [historique](https://fr.wikipedia.org/wiki/D%C3%A9fense_est-indienne?action=history)
- [Défense française](https://fr.wikipedia.org/wiki/D%C3%A9fense_fran%C3%A7aise) — [historique](https://fr.wikipedia.org/wiki/D%C3%A9fense_fran%C3%A7aise?action=history)
- [Défense hollandaise](https://fr.wikipedia.org/wiki/D%C3%A9fense_hollandaise) — [historique](https://fr.wikipedia.org/wiki/D%C3%A9fense_hollandaise?action=history)
- [Défense moderne](https://fr.wikipedia.org/wiki/D%C3%A9fense_moderne) — [historique](https://fr.wikipedia.org/wiki/D%C3%A9fense_moderne?action=history)
- [Défense nimzo-indienne](https://fr.wikipedia.org/wiki/D%C3%A9fense_nimzo-indienne) — [historique](https://fr.wikipedia.org/wiki/D%C3%A9fense_nimzo-indienne?action=history)
- [Défense ouest-indienne](https://fr.wikipedia.org/wiki/D%C3%A9fense_ouest-indienne) — [historique](https://fr.wikipedia.org/wiki/D%C3%A9fense_ouest-indienne?action=history)
- [Défense russe](https://fr.wikipedia.org/wiki/D%C3%A9fense_Petrov) — [historique](https://fr.wikipedia.org/wiki/D%C3%A9fense_Petrov?action=history)
- [Défense scandinave](https://fr.wikipedia.org/wiki/D%C3%A9fense_scandinave) — [historique](https://fr.wikipedia.org/wiki/D%C3%A9fense_scandinave?action=history)
- [Défense semi-slave](https://fr.wikipedia.org/wiki/D%C3%A9fense_semi-slave) — [historique](https://fr.wikipedia.org/wiki/D%C3%A9fense_semi-slave?action=history)
- [Défense sicilienne](https://fr.wikipedia.org/wiki/D%C3%A9fense_sicilienne) — [historique](https://fr.wikipedia.org/wiki/D%C3%A9fense_sicilienne?action=history)
- [Défense slave](https://fr.wikipedia.org/wiki/D%C3%A9fense_slave) — [historique](https://fr.wikipedia.org/wiki/D%C3%A9fense_slave?action=history)
- [Gambit dame](https://fr.wikipedia.org/wiki/Gambit_dame) — [historique](https://fr.wikipedia.org/wiki/Gambit_dame?action=history)
- [Gambit dame accepté](https://fr.wikipedia.org/wiki/Gambit_dame_accept%C3%A9) — [historique](https://fr.wikipedia.org/wiki/Gambit_dame_accept%C3%A9?action=history)
- [Gambit dame refusé](https://fr.wikipedia.org/wiki/Gambit_dame_refus%C3%A9) — [historique](https://fr.wikipedia.org/wiki/Gambit_dame_refus%C3%A9?action=history)
- [Gambit du roi](https://fr.wikipedia.org/wiki/Gambit_du_roi) — [historique](https://fr.wikipedia.org/wiki/Gambit_du_roi?action=history)
- [Ouverture anglaise](https://fr.wikipedia.org/wiki/Ouverture_anglaise) — [historique](https://fr.wikipedia.org/wiki/Ouverture_anglaise?action=history)
- [Partie catalane](https://fr.wikipedia.org/wiki/Partie_catalane) — [historique](https://fr.wikipedia.org/wiki/Partie_catalane?action=history)
- [Partie des quatre cavaliers](https://fr.wikipedia.org/wiki/Partie_des_quatre_cavaliers) — [historique](https://fr.wikipedia.org/wiki/Partie_des_quatre_cavaliers?action=history)
- [Partie espagnole](https://fr.wikipedia.org/wiki/Partie_espagnole) — [historique](https://fr.wikipedia.org/wiki/Partie_espagnole?action=history)
- [Partie italienne](https://fr.wikipedia.org/wiki/Partie_italienne) — [historique](https://fr.wikipedia.org/wiki/Partie_italienne?action=history)
- [Partie viennoise](https://fr.wikipedia.org/wiki/Partie_viennoise) — [historique](https://fr.wikipedia.org/wiki/Partie_viennoise?action=history)
- [Partie écossaise](https://fr.wikipedia.org/wiki/Partie_%C3%A9cossaise) — [historique](https://fr.wikipedia.org/wiki/Partie_%C3%A9cossaise?action=history)
- [Système de Londres](https://fr.wikipedia.org/wiki/Syst%C3%A8me_de_Londres) — [historique](https://fr.wikipedia.org/wiki/Syst%C3%A8me_de_Londres?action=history)
